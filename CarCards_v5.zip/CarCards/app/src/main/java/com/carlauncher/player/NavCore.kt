package com.carlauncher.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/** موقعیت‌یاب و مسیریاب مشترک بین صفحه‌ی کارت‌ها و صفحه‌ی نقشه */
object NavCore {
    var route: Route? = null
        private set
    var tracker: RouteTracker? = null
        private set
    var dest: Dest? = null
        private set
    var progress: Progress? = null
        private set
    var lastLoc: Location? = null
        private set
    var lastLocAt = 0L
        private set
    var curKmh = 0f
        private set
    var routeVersion = 0
        private set
    var arrivedFlag = false

    private var users = 0
    private var lm: LocationManager? = null
    private var lastReroute = 0L
    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<() -> Unit>()

    private val locListener = object : LocationListener {
        override fun onLocationChanged(l: Location) { handle(l) }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    fun addListener(l: () -> Unit) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    private fun fire() {
        for (l in ArrayList(listeners)) l()
    }

    private fun hasPerm(ctx: Context) =
        Build.VERSION.SDK_INT < 23 ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun start(ctx: Context) {
        users++
        if (users == 1) requestUpdates(ctx)
    }

    fun stop() {
        if (users > 0) users--
        if (users == 0) {
            try { lm?.removeUpdates(locListener) } catch (_: Exception) {}
        }
    }

    /** بعد از گرفتن مجوز موقعیت صدا زده می‌شود */
    fun permissionChanged(ctx: Context) {
        if (users > 0) requestUpdates(ctx)
    }

    private fun requestUpdates(ctx: Context) {
        if (!hasPerm(ctx)) return
        try {
            val m = ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm = m
            m.removeUpdates(locListener)
            if (m.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
            }
            if (m.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 0f, locListener)
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    fun lastKnown(ctx: Context): Location? {
        if (!hasPerm(ctx)) return null
        return try {
            val m = ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            m.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: m.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (e: Exception) {
            null
        }
    }

    private fun handle(l: Location) {
        lastLoc = l
        lastLocAt = SystemClock.elapsedRealtime()
        var k = if (l.hasSpeed()) l.speed * 3.6f else 0f
        if (k < 3f) k = 0f
        curKmh = k
        val tr = tracker
        if (tr != null) {
            val p = tr.update(l.latitude, l.longitude, l.accuracy)
            progress = p
            val now = SystemClock.elapsedRealtime()
            if (p.offCount >= 3 && now - lastReroute > 12000) reroute(l)
            val nx = p.next
            if (p.remaining < 35 && nx != null && nx.type == "arrive") {
                clear()
                arrivedFlag = true
            }
        }
        fire()
    }

    fun navigateTo(d: Dest, fLat: Double, fLon: Double, done: (String?) -> Unit) {
        Thread {
            var err: String? = null
            var r: Route? = null
            try {
                r = Nav.route(fLat, fLon, d.lat, d.lon)
                if (r == null) err = "مسیری پیدا نشد."
            } catch (e: Exception) {
                err = "خطا در مسیریابی. اینترنت را بررسی کنید."
            }
            val rr = r
            main.post {
                if (rr != null) setRoute(rr, d)
                done(err)
            }
        }.start()
    }

    private fun setRoute(r: Route, d: Dest) {
        route = r
        dest = d
        val tr = RouteTracker(r)
        tracker = tr
        val l = lastLoc
        progress = if (l != null) {
            tr.update(l.latitude, l.longitude, l.accuracy)
        } else {
            Progress(0, r.distance, r.duration, 0.0, r.steps.getOrNull(1)?.startDist ?: 0.0, r.steps.getOrNull(1))
        }
        routeVersion++
        fire()
    }

    private fun reroute(l: Location) {
        val d = dest ?: return
        lastReroute = SystemClock.elapsedRealtime()
        Thread {
            try {
                val r = Nav.route(l.latitude, l.longitude, d.lat, d.lon)
                if (r != null) main.post { setRoute(r, d) }
            } catch (e: Exception) {
            }
        }.start()
    }

    fun clear() {
        route = null
        tracker = null
        dest = null
        progress = null
        routeVersion++
        fire()
    }
}
