package com.carlauncher.player

import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.max
import kotlin.math.sqrt

/** اندازه‌گیری شدت صدا (Visualizer) و تشخیص ضرب برای رسم نوار قلب روی خط قرمز */
class AudioLevel(private val onBeat: (Float) -> Unit) {
    private var vis: Visualizer? = null
    private var ok = false
    @Volatile private var lastData = 0L
    private var avg = 0.05f
    private var lastBeat = 0L
    private val main = Handler(Looper.getMainLooper())

    /** آیا داده‌ی واقعی صدا دریافت می‌شود؟ */
    val live: Boolean
        get() = ok && SystemClock.uptimeMillis() - lastData < 1500

    fun attach(session: Int) {
        release()
        try {
            val v = Visualizer(session)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[0])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, w: ByteArray?, r: Int) {
                    if (w == null || w.isEmpty()) return
                    var sum = 0.0
                    for (b in w) {
                        val x = (b.toInt() and 0xFF) - 128
                        sum += (x * x).toDouble()
                    }
                    val rms = (sqrt(sum / w.size) / 128.0).toFloat()
                    val now = SystemClock.uptimeMillis()
                    if (rms > 0.012f) lastData = now
                    if (rms > avg * 1.35f + 0.02f && rms > 0.05f && now - lastBeat > 260) {
                        lastBeat = now
                        val a = (rms * 3.2f).coerceIn(0.3f, 1f)
                        main.post { onBeat(a) }
                    }
                    avg += (rms - avg) * 0.06f
                    avg = max(avg, 0.01f)
                }
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, r: Int) {}
            }, Visualizer.getMaxCaptureRate(), true, false)
            v.setEnabled(true)
            vis = v
            ok = true
        } catch (t: Throwable) {
            ok = false
        }
    }

    fun release() {
        try {
            vis?.setEnabled(false)
            vis?.release()
        } catch (_: Throwable) {
        }
        vis = null
        ok = false
    }
}
