package com.carlauncher.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** نقشه‌ی تمام‌صفحه با مسیریابی؛ موقعیت و مسیر از NavCore می‌آید */
class MapActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var mapView: MapView
    private lateinit var routeLine: Polyline
    private lateinit var carMarker: Marker
    private lateinit var destMarker: Marker
    private var destOnMap = false
    private var follow = true
    private var firstFix = false
    private var orient = 0f
    private var drawnVersion = -1
    private var pendingOverview = false
    private val handler = Handler(Looper.getMainLooper())
    private val red = 0xFFFF2A2A.toInt()

    private lateinit var instrCard: LinearLayout
    private lateinit var instrArrow: ImageView
    private lateinit var instrDist: TextView
    private lateinit var instrText: TextView
    private lateinit var pillIcon: ImageView
    private lateinit var pillText: TextView
    private lateinit var pillClose: ImageView
    private lateinit var recenterBtn: ImageButton

    private var downX = 0f
    private var downY = 0f
    private var longRun: Runnable? = null
    private val navL: () -> Unit = { onNav() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs.get(this)
        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, android.preference.PreferenceManager.getDefaultSharedPreferences(applicationContext))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        NavCore.start(this)
        NavCore.addListener(navL)
        drawnVersion = -1
        onNav()
    }

    override fun onPause() {
        NavCore.removeListener(navL)
        NavCore.stop()
        mapView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        mapView.onDetach()
        super.onDestroy()
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // =====================================================================
    private fun darkBtn(res: Int, sizeU: Int): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(u(11), u(11), u(11), u(11))
        val g = GradientDrawable()
        g.setShape(GradientDrawable.OVAL)
        g.setColor(0xDD0B0B0D.toInt())
        g.setStroke(u(2), red)
        b.background = g
        b.setColorFilter(Color.WHITE)
        return b
    }

    private fun arrowBitmap(): Bitmap {
        val s = u(56)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        val f = s.toFloat()
        path.moveTo(f / 2f, f * 0.06f)
        path.lineTo(f * 0.90f, f * 0.92f)
        path.lineTo(f / 2f, f * 0.72f)
        path.lineTo(f * 0.10f, f * 0.92f)
        path.close()
        p.color = red
        p.style = Paint.Style.FILL
        c.drawPath(path, p)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = f * 0.07f
        c.drawPath(path, p)
        return bmp
    }

    private fun pinBitmap(): Bitmap {
        val s = u(34)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val f = s.toFloat()
        p.color = Color.WHITE
        c.drawCircle(f / 2, f / 2, f * 0.46f, p)
        p.color = red
        c.drawCircle(f / 2, f / 2, f * 0.34f, p)
        p.color = Color.WHITE
        c.drawCircle(f / 2, f / 2, f * 0.12f, p)
        return bmp
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(Color.BLACK)

        mapView = MapView(this)
        mapView.setMultiTouchControls(true)
        mapView.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        mapView.setTilesScaledToDpi(true)
        mapView.setMinZoomLevel(3.0)
        mapView.setMaxZoomLevel(19.0)
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.overlayManager.tilesOverlay.setColorFilter(
            if (prefs.mapStyle == 2) null else TilesOverlay.INVERT_COLORS
        )
        mapView.controller.setZoom(3.5)

        routeLine = Polyline()
        routeLine.outlinePaint.color = red
        routeLine.outlinePaint.strokeWidth = u(8).toFloat()
        routeLine.outlinePaint.strokeCap = Paint.Cap.ROUND
        routeLine.outlinePaint.strokeJoin = Paint.Join.ROUND
        mapView.overlays.add(routeLine)

        destMarker = Marker(mapView)
        destMarker.icon = BitmapDrawable(resources, pinBitmap())
        destMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        destMarker.setInfoWindow(null)

        carMarker = Marker(mapView)
        carMarker.icon = BitmapDrawable(resources, arrowBitmap())
        carMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        carMarker.setInfoWindow(null)
        mapView.overlays.add(carMarker)

        val ll = NavCore.lastLoc ?: NavCore.lastKnown(this)
        if (ll != null) {
            carMarker.position = GeoPoint(ll.latitude, ll.longitude)
            mapView.controller.setZoom(15.5)
            mapView.controller.setCenter(carMarker.position)
            firstFix = true
        }

        mapView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    cancelLong()
                    val r = Runnable { onMapLongPress(downX, downY) }
                    longRun = r
                    handler.postDelayed(r, 750)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(ev.x - downX) > u(14) || abs(ev.y - downY) > u(14)) {
                        cancelLong()
                        follow = false
                        recenterBtn.alpha = 1f
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> cancelLong()
            }
            false
        }
        root.addView(mapView, FrameLayout.LayoutParams(MATCH, MATCH))

        // کارت پیچ بعدی
        instrCard = LinearLayout(this)
        instrCard.orientation = LinearLayout.VERTICAL
        instrCard.setPadding(u(16), u(10), u(20), u(10))
        val ig = GradientDrawable()
        ig.setColor(0xEE0B0B0D.toInt())
        ig.setCornerRadius(u(16).toFloat())
        ig.setStroke(u(2), red)
        instrCard.background = ig
        instrCard.visibility = View.GONE
        val ir = LinearLayout(this)
        ir.gravity = Gravity.CENTER_VERTICAL
        instrArrow = ImageView(this)
        instrArrow.setImageResource(R.drawable.ic_turn)
        instrArrow.setColorFilter(red)
        ir.addView(instrArrow, lp(u(42), u(42)))
        instrDist = label(32f, Color.WHITE)
        ir.addView(instrDist, lp(WRAP, WRAP).also { it.leftMargin = u(10) })
        instrCard.addView(ir)
        instrText = label(15f, 0xFFB0B0B8.toInt())
        instrText.maxWidth = u(320)
        instrCard.addView(instrText, lp(WRAP, WRAP).also { it.topMargin = u(2) })
        instrCard.setOnClickListener { showDirections() }
        root.addView(instrCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).also {
            it.setMargins(u(16), u(16), 0, 0)
        })

        // دکمه‌های سمت راست
        val ctrl = LinearLayout(this)
        ctrl.orientation = LinearLayout.VERTICAL
        ctrl.gravity = Gravity.CENTER_HORIZONTAL
        val close = darkBtn(R.drawable.ic_close, 48)
        close.setOnClickListener { finish() }
        val search = darkBtn(R.drawable.ic_search, 48)
        search.setOnClickListener { openSearch() }
        recenterBtn = darkBtn(R.drawable.ic_nav, 48)
        recenterBtn.setOnClickListener { follow = true; recenter() }
        val zin = darkBtn(R.drawable.ic_plus, 48)
        zin.setOnClickListener { mapView.controller.zoomIn() }
        val zout = darkBtn(R.drawable.ic_minus, 48)
        zout.setOnClickListener { mapView.controller.zoomOut() }
        for (v in arrayOf(close, search, recenterBtn, zin, zout)) {
            ctrl.addView(v, lp(u(48), u(48)).also { it.topMargin = u(10) })
        }
        root.addView(ctrl, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).also {
            it.setMargins(0, u(8), u(16), 0)
        })

        // قرص پایین
        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(u(16), u(8), u(12), u(8))
        val pg = GradientDrawable()
        pg.setColor(0xEE0B0B0D.toInt())
        pg.setCornerRadius(u(26).toFloat())
        pg.setStroke(u(2), red)
        pill.background = pg
        pillIcon = ImageView(this)
        pillIcon.setImageResource(R.drawable.ic_search)
        pillIcon.setColorFilter(Color.WHITE)
        pill.addView(pillIcon, lp(u(26), u(26)))
        pillText = label(18f, Color.WHITE)
        pillText.setSingleLine(true)
        pillText.ellipsize = TextUtils.TruncateAt.END
        pill.addView(pillText, lp(WRAP, WRAP).also { it.leftMargin = u(10) })
        pillClose = ImageView(this)
        pillClose.setImageResource(R.drawable.ic_close)
        pillClose.setColorFilter(red)
        pillClose.setPadding(u(6), u(6), u(6), u(6))
        pillClose.setOnClickListener { NavCore.clear() }
        pill.addView(pillClose, lp(u(32), u(32)).also { it.leftMargin = u(8) })
        pill.setOnClickListener { if (NavCore.route == null) openSearch() else showDirections() }
        root.addView(pill, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).also {
            it.setMargins(u(16), 0, 0, u(16))
        })

        val attr = label(9f, 0x99FFFFFF.toInt())
        attr.text = "© OpenStreetMap contributors"
        root.addView(attr, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).also {
            it.setMargins(0, 0, u(14), u(6))
        })
        setContentView(root)
    }

    private fun cancelLong() {
        val r = longRun
        if (r != null) handler.removeCallbacks(r)
        longRun = null
    }

    private fun recenter() {
        val l = NavCore.lastLoc ?: NavCore.lastKnown(this)
        if (l != null) mapView.controller.animateTo(GeoPoint(l.latitude, l.longitude))
        recenterBtn.alpha = 0.7f
    }

    // =====================================================================
    private fun onNav() {
        if (NavCore.arrivedFlag) {
            NavCore.arrivedFlag = false
            toast("به مقصد رسیدید")
        }
        val l = NavCore.lastLoc
        if (l != null) {
            val gp = GeoPoint(l.latitude, l.longitude)
            carMarker.position = gp
            if (!firstFix) {
                firstFix = true
                mapView.controller.setZoom(16.0)
                mapView.controller.setCenter(gp)
            }
            if (follow && !pendingOverview) {
                mapView.controller.animateTo(gp)
                if (!prefs.northUp && l.hasBearing() && l.speed > 1.5f) {
                    val tgt = -l.bearing
                    val diff = ((tgt - orient + 540f) % 360f) - 180f
                    orient += diff * 0.35f
                    mapView.mapOrientation = orient
                }
            }
        }
        if (drawnVersion != NavCore.routeVersion) {
            drawnVersion = NavCore.routeVersion
            redrawRoute()
        }
        updateInstr()
        mapView.invalidate()
    }

    private fun redrawRoute() {
        val r = NavCore.route
        if (r == null) {
            routeLine.setPoints(ArrayList<GeoPoint>())
            if (destOnMap) {
                mapView.overlays.remove(destMarker)
                destOnMap = false
            }
            return
        }
        val pts = ArrayList<GeoPoint>()
        for (i in r.lats.indices) pts.add(GeoPoint(r.lats[i], r.lons[i]))
        routeLine.setPoints(pts)
        val d = NavCore.dest
        if (d != null) {
            destMarker.position = GeoPoint(d.lat, d.lon)
            if (!destOnMap) {
                mapView.overlays.add(mapView.overlays.size - 1, destMarker)
                destOnMap = true
            }
        }
        if (pendingOverview) {
            pendingOverview = false
            follow = false
            mapView.mapOrientation = 0f
            orient = 0f
            try {
                mapView.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, u(90))
            } catch (e: Exception) {
            }
            handler.postDelayed({
                if (NavCore.route != null) {
                    follow = true
                    recenter()
                }
            }, 6000)
        }
    }

    private fun updateInstr() {
        val pr = NavCore.progress
        if (NavCore.route == null || pr == null) {
            instrCard.visibility = View.GONE
            pillIcon.setImageResource(R.drawable.ic_search)
            pillText.setFa("جستجوی مقصد")
            pillClose.visibility = View.GONE
            return
        }
        instrCard.visibility = View.VISIBLE
        pillIcon.setImageResource(R.drawable.ic_car)
        pillClose.visibility = View.VISIBLE
        val nx = pr.next
        if (nx != null) {
            instrArrow.rotation = Nav.arrowAngle(nx.type, nx.modifier)
            instrDist.setFa(Nav.fmtDist(pr.distToNext), true)
            instrText.setFa(nx.text)
        }
        val eta = Date(System.currentTimeMillis() + (pr.remainingTime * 1000).toLong())
        val fmt = SimpleDateFormat(if (prefs.clock24) "HH:mm" else "hh:mm a", Locale.ENGLISH)
        pillText.setFa(Nav.fmtDur(pr.remainingTime) + "  |  " + Nav.fmtDist(pr.remaining) + "  |  " + fmt.format(eta), true)
    }

    private fun showDirections() {
        val r = NavCore.route ?: return
        val items = r.steps.map { Nav.fmtDist(it.dist) + "   " + it.text }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(NavCore.dest?.name ?: "مسیر")
            .setItems(items) { _, _ -> }
            .show()
    }

    // =====================================================================
    private fun openSearch() {
        val i = Intent(this, SearchActivity::class.java)
        val l = NavCore.lastLoc ?: NavCore.lastKnown(this)
        if (l != null) {
            i.putExtra("lat", l.latitude)
            i.putExtra("lon", l.longitude)
        }
        startActivityForResult(i, 500)
    }

    private fun startNav(d: Dest) {
        val l = NavCore.lastLoc ?: NavCore.lastKnown(this)
        val fLat: Double
        val fLon: Double
        if (l != null) {
            fLat = l.latitude
            fLon = l.longitude
        } else {
            val c = mapView.mapCenter
            fLat = c.latitude
            fLon = c.longitude
        }
        pillText.setFa("در حال مسیریابی...")
        pendingOverview = true
        NavCore.navigateTo(d, fLat, fLon) { err ->
            if (err != null) {
                pendingOverview = false
                toast(err)
            }
        }
    }

    private fun onMapLongPress(x: Float, y: Float) {
        val gp = mapView.projection.fromPixels(x.toInt(), y.toInt())
        val lat = gp.latitude
        val lon = gp.longitude
        Thread {
            val d = try { Nav.reverse(lat, lon) } catch (e: Exception) { Dest("نقطه‌ی انتخابی", "", lat, lon) }
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("مسیریابی به این نقطه؟")
                    .setMessage(d.name)
                    .setPositiveButton("بله") { _, _ -> startNav(d) }
                    .setNegativeButton("خیر", null)
                    .show()
            }
        }.start()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 500 && res == RESULT_OK && data != null) {
            startNav(
                Dest(
                    data.getStringExtra("name") ?: "",
                    data.getStringExtra("addr") ?: "",
                    data.getDoubleExtra("lat", 0.0),
                    data.getDoubleExtra("lon", 0.0)
                )
            )
        }
    }
}
