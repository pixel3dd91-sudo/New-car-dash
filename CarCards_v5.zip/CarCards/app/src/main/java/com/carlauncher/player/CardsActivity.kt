package com.carlauncher.player

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class CardsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var music: MusicController
    private lateinit var radios: Radios
    private lateinit var am: AudioManager
    private lateinit var level: AudioLevel
    private val handler = Handler(Looper.getMainLooper())
    private val red = 0xFFFF2A2A.toInt()
    private val gray = 0xFF9A9AA0.toInt()
    private var attachedSession = -2
    private var askedPerms = false
    private var artKey = ""
    private val cards = ArrayList<FlipCard>()

    private lateinit var neon: NeonLineView
    private lateinit var clockTv: TextView
    private lateinit var dateTv: TextView
    private lateinit var btStatus: ImageView
    private lateinit var wifiStatus: ImageView
    private lateinit var gpsStatus: ImageView

    private lateinit var cardMusic: FlipCard
    private lateinit var cardBt: FlipCard
    private lateinit var cardRadio: FlipCard
    private lateinit var cardGps: FlipCard

    private lateinit var musicSub: TextView
    private lateinit var btSub: TextView
    private lateinit var radioSub: TextView
    private lateinit var gpsSpeed: TextView
    private lateinit var gpsUnit: TextView
    private lateinit var gpsHint: TextView
    private lateinit var gpsArrow: ImageView

    private lateinit var mArt: CoverView
    private lateinit var mTitle: TextView
    private lateinit var mArtist: TextView
    private lateinit var mProg: ProgressLine
    private lateinit var mPlay: ImageButton

    private lateinit var btSwitch: NeonSwitch
    private lateinit var btState: TextView
    private lateinit var btTitle: TextView
    private lateinit var btPlay: ImageButton

    private lateinit var rName: TextView
    private lateinit var rStatus: TextView
    private lateinit var rPlay: ImageButton

    private val navL: () -> Unit = { onNav() }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 450)
        }
    }

    // =====================================================================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs.get(this)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        radios = Radios(this)
        level = AudioLevel { a -> neon.beat(a) }
        music = MusicController(this) { runOnUiThread { tickMusic() } }
        buildUi()
        music.start()
        requestPerms()
    }

    override fun onResume() {
        super.onResume()
        music.ext.start()
        music.loadIfPermitted()
        NavCore.start(this)
        NavCore.addListener(navL)
        handler.post(ticker)
        onNav()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        NavCore.removeListener(navL)
        NavCore.stop()
        music.svc?.saveState()
        level.release()
        attachedSession = -2
        super.onPause()
    }

    override fun onDestroy() {
        music.stop()
        super.onDestroy()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        for (c in cards) {
            if (c.flipped) {
                c.flipTo(false)
                return
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_NEXT -> { music.next(); return true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { music.prev(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK -> { music.toggle(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // =====================================================================
    // ساخت رابط
    private fun topIcon(res: Int): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(u(11), u(11), u(11), u(11))
        b.background = rippleBg(0, 0, 0, true, 0f)
        b.setColorFilter(0xFFE6E6E8.toInt())
        return b
    }

    private fun statusIcon(res: Int): ImageView {
        val i = ImageView(this)
        i.setImageResource(res)
        i.setColorFilter(Color.WHITE)
        i.alpha = 0.3f
        return i
    }

    private fun ctl(res: Int, sizeU: Int, padU: Int, filled: Boolean): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(u(padU), u(padU), u(padU), u(padU))
        b.background = if (filled) rippleBg(0xFFD81818.toInt(), 0, 0, true, 0f)
        else rippleBg(0, 0x66FFFFFF, u(2), true, 0f)
        b.setColorFilter(Color.WHITE)
        return b
    }

    private fun spaced(t: TextView, sp: Float): TextView {
        t.letterSpacing = sp
        return t
    }

    private fun buildFront(card: FlipCard, iconRes: Int, title: String): TextView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        val ic = ImageView(this)
        ic.setImageResource(iconRes)
        col.addView(ic, lp(u(96), u(96)))
        val t = spaced(label(16f, Color.WHITE), 0.16f)
        t.setFa(title, true)
        t.gravity = Gravity.CENTER
        col.addView(t, lp(WRAP, WRAP).also { it.topMargin = u(14) })
        val s = label(12f, red)
        s.setSingleLine(true)
        s.gravity = Gravity.CENTER
        s.ellipsize = TextUtils.TruncateAt.END
        col.addView(s, lp(MATCH, WRAP).also {
            it.topMargin = u(6)
            it.leftMargin = u(10)
            it.rightMargin = u(10)
        })
        card.front.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        return s
    }

    private fun addClose(card: FlipCard) {
        val x = label(22f, gray)
        x.text = "✕"
        x.setPadding(u(14), u(8), u(14), u(8))
        x.setOnClickListener { card.flipTo(false) }
        card.back.addView(x, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END))
    }

    private fun backColumn(card: FlipCard): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(u(12), u(30), u(12), u(14))
        card.back.addView(c, FrameLayout.LayoutParams(MATCH, MATCH))
        return c
    }

    private fun controlsRow(prev: ImageButton, play: ImageButton, next: ImageButton): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER
        r.addView(prev, lp(u(44), u(44)))
        r.addView(play, lp(u(62), u(62)).also { it.leftMargin = u(12); it.rightMargin = u(12) })
        r.addView(next, lp(u(44), u(44)))
        return r
    }

    private fun linkText(text: String, click: () -> Unit): TextView {
        val t = spaced(label(12f, red), 0.12f)
        t.setFa(text, true)
        t.setPadding(u(10), u(8), u(10), u(8))
        t.setOnClickListener { click() }
        return t
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(Color.BLACK)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---------- نوار بالا ----------
        val top = FrameLayout(this)
        val left = LinearLayout(this)
        left.gravity = Gravity.CENTER_VERTICAL
        val appsBtn = topIcon(R.drawable.ic_apps)
        appsBtn.setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        val phoneBtn = topIcon(R.drawable.ic_phone)
        phoneBtn.setOnClickListener {
            val p = prefs.phonePkg
            if (p.isNotEmpty()) {
                val i = packageManager.getLaunchIntentForPackage(p)
                if (i != null) startActivity(i) else pickApp(201)
            } else {
                try { startActivity(Intent(Intent.ACTION_DIAL)) } catch (e: Exception) { pickApp(201) }
            }
        }
        phoneBtn.setOnLongClickListener { pickApp(201); true }
        left.addView(appsBtn, lp(u(52), u(52)))
        left.addView(phoneBtn, lp(u(52), u(52)).also { it.leftMargin = u(6) })
        top.addView(left, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL).also {
            it.leftMargin = u(24)
        })

        val clockCol = LinearLayout(this)
        clockCol.orientation = LinearLayout.VERTICAL
        clockCol.gravity = Gravity.CENTER_HORIZONTAL
        clockTv = label(50f, Color.WHITE)
        dateTv = label(14f, gray)
        clockCol.addView(clockTv, lp(WRAP, WRAP))
        clockCol.addView(dateTv, lp(WRAP, WRAP))
        top.addView(clockCol, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val right = LinearLayout(this)
        right.gravity = Gravity.CENTER_VERTICAL
        btStatus = statusIcon(R.drawable.ic_bluetooth)
        wifiStatus = statusIcon(R.drawable.ic_wifi)
        gpsStatus = statusIcon(R.drawable.ic_gps)
        right.addView(btStatus, lp(u(20), u(20)))
        right.addView(wifiStatus, lp(u(20), u(20)).also { it.leftMargin = u(12) })
        right.addView(gpsStatus, lp(u(20), u(20)).also { it.leftMargin = u(12) })
        val setBtn = topIcon(R.drawable.ic_settings)
        setBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        right.addView(setBtn, lp(u(52), u(52)).also { it.leftMargin = u(10) })
        top.addView(right, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL).also {
            it.rightMargin = u(24)
        })
        col.addView(top, lp(MATCH, u(86)))

        // ---------- صحنه: خط قرمز + کارت‌ها ----------
        val stage = FrameLayout(this)
        col.addView(stage, lp(MATCH, 0).also { it.weight = 1f })
        neon = NeonLineView(this)
        neon.insetX = u(46).toFloat()
        neon.insetTop = u(6).toFloat()
        neon.insetBottom = u(66).toFloat()
        neon.cardInset = u(16).toFloat()
        neon.cardGap = u(14).toFloat()
        neon.cardCount = 4
        stage.addView(neon, FrameLayout.LayoutParams(MATCH, MATCH))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        stage.addView(row, FrameLayout.LayoutParams(MATCH, MATCH).also {
            it.setMargins(u(62), u(22), u(62), u(82))
        })
        cardMusic = FlipCard(this)
        cardBt = FlipCard(this)
        cardRadio = FlipCard(this)
        cardGps = FlipCard(this)
        val all = listOf(cardMusic, cardBt, cardRadio, cardGps)
        for (i in all.indices) {
            row.addView(all[i], lp(0, MATCH).also {
                it.weight = 1f
                if (i > 0) it.leftMargin = u(14)
            })
            cards.add(all[i])
        }

        musicSub = buildFront(cardMusic, R.drawable.ic_card_music, "MUSIC")
        btSub = buildFront(cardBt, R.drawable.ic_card_bt, "BLUETOOTH")
        radioSub = buildFront(cardRadio, R.drawable.ic_card_radio, "RADIO")
        cardMusic.front.setOnClickListener { openCard(cardMusic) }
        cardBt.front.setOnClickListener { openCard(cardBt) }
        cardRadio.front.setOnClickListener { openCard(cardRadio) }
        buildGpsFront()
        buildMusicBack()
        buildBtBack()
        buildRadioBack()
        for (c in cards) {
            c.front.setOnTouchListener { v, ev ->
                if (ev.action == MotionEvent.ACTION_DOWN) v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                else if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }

        setContentView(root)

        // انیمیشن ورود کارت‌ها
        for (i in cards.indices) {
            val c = cards[i]
            c.alpha = 0f
            c.translationY = u(46).toFloat()
            c.animate().alpha(1f).translationY(0f).setStartDelay(i * 90L).setDuration(520).start()
        }
    }

    private fun buildGpsFront() {
        val g = LinearLayout(this)
        g.orientation = LinearLayout.VERTICAL
        g.gravity = Gravity.CENTER
        val ic = ImageView(this)
        ic.setImageResource(R.drawable.ic_card_gps)
        g.addView(ic, lp(u(44), u(44)))
        gpsSpeed = label(84f, Color.WHITE)
        gpsSpeed.typeface = Typeface.create(Fonts.forText(this, "0", true), Typeface.BOLD_ITALIC)
        gpsSpeed.text = "0"
        gpsSpeed.gravity = Gravity.CENTER
        g.addView(gpsSpeed, lp(WRAP, WRAP).also { it.topMargin = u(4) })
        gpsUnit = spaced(label(15f, red), 0.2f)
        gpsUnit.setFa("KM/H", true)
        g.addView(gpsUnit, lp(WRAP, WRAP))
        val hintRow = LinearLayout(this)
        hintRow.gravity = Gravity.CENTER
        gpsArrow = ImageView(this)
        gpsArrow.setImageResource(R.drawable.ic_turn)
        gpsArrow.setColorFilter(red)
        gpsArrow.visibility = View.GONE
        hintRow.addView(gpsArrow, lp(u(24), u(24)))
        gpsHint = label(12f, gray)
        gpsHint.setSingleLine(true)
        hintRow.addView(gpsHint, lp(WRAP, WRAP).also { it.leftMargin = u(4) })
        g.addView(hintRow, lp(WRAP, WRAP).also { it.topMargin = u(16) })
        cardGps.front.addView(g, FrameLayout.LayoutParams(MATCH, MATCH))
        cardGps.front.setOnClickListener { startActivity(Intent(this, MapActivity::class.java)) }
    }

    private fun buildMusicBack() {
        val c = backColumn(cardMusic)
        mArt = CoverView(this)
        c.addView(mArt, lp(u(88), u(88)))
        mTitle = label(17f, Color.WHITE)
        mTitle.setSingleLine(true)
        mTitle.ellipsize = TextUtils.TruncateAt.MARQUEE
        mTitle.marqueeRepeatLimit = -1
        mTitle.isSelected = true
        mTitle.gravity = Gravity.CENTER
        c.addView(mTitle, lp(MATCH, WRAP).also { it.topMargin = u(10) })
        mArtist = label(13f, red)
        mArtist.setSingleLine(true)
        mArtist.gravity = Gravity.CENTER
        c.addView(mArtist, lp(MATCH, WRAP))
        mProg = ProgressLine(this)
        mProg.accent = red
        mProg.track = 0x44FFFFFF
        mProg.thumb = Color.WHITE
        mProg.onSeek = { f -> music.svc?.let { it.seekTo((f * it.duration).toInt()) } }
        c.addView(mProg, lp(MATCH, u(24)).also { it.topMargin = u(8) })
        val prev = ctl(R.drawable.ic_prev, 44, 11, false)
        prev.setOnClickListener { music.svc?.prev() }
        mPlay = ctl(R.drawable.ic_pause, 62, 16, true)
        mPlay.setOnClickListener { music.svc?.toggle() }
        val next = ctl(R.drawable.ic_next, 44, 11, false)
        next.setOnClickListener { music.svc?.next() }
        c.addView(controlsRow(prev, mPlay, next), lp(MATCH, WRAP).also { it.topMargin = u(8) })
        c.addView(linkText("LIBRARY") { startActivity(Intent(this, LibraryActivity::class.java)) }, lp(WRAP, WRAP))
        addClose(cardMusic)
    }

    private fun buildBtBack() {
        val c = backColumn(cardBt)
        btState = spaced(label(13f, red), 0.16f)
        btState.setFa("BLUETOOTH", true)
        c.addView(btState, lp(WRAP, WRAP))
        btSwitch = NeonSwitch(this)
        btSwitch.onTap = { radios.toggleBt(this) }
        c.addView(btSwitch, lp(u(118), u(54)).also { it.topMargin = u(12) })
        btTitle = label(15f, Color.WHITE)
        btTitle.setSingleLine(true)
        btTitle.ellipsize = TextUtils.TruncateAt.END
        btTitle.gravity = Gravity.CENTER
        c.addView(btTitle, lp(MATCH, WRAP).also { it.topMargin = u(22) })
        val sub = label(11f, gray)
        sub.setFa("BLUETOOTH AUDIO")
        sub.gravity = Gravity.CENTER
        c.addView(sub, lp(MATCH, WRAP))
        val prev = ctl(R.drawable.ic_prev, 44, 11, false)
        prev.setOnClickListener { btCtl(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
        btPlay = ctl(R.drawable.ic_pause, 62, 16, true)
        btPlay.setOnClickListener { btCtl(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
        val next = ctl(R.drawable.ic_next, 44, 11, false)
        next.setOnClickListener { btCtl(android.view.KeyEvent.KEYCODE_MEDIA_NEXT) }
        c.addView(controlsRow(prev, btPlay, next), lp(MATCH, WRAP).also { it.topMargin = u(14) })
        c.addView(linkText("PAIRING") {
            try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) { toast("باز کردن تنظیمات ممکن نشد.") }
        }, lp(WRAP, WRAP))
        addClose(cardBt)
    }

    private fun buildRadioBack() {
        val c = backColumn(cardRadio)
        val tag = spaced(label(12f, red), 0.16f)
        tag.setFa("INTERNET RADIO", true)
        c.addView(tag, lp(WRAP, WRAP))
        rName = label(19f, Color.WHITE)
        rName.maxLines = 2
        rName.gravity = Gravity.CENTER
        c.addView(rName, lp(MATCH, WRAP).also { it.topMargin = u(14) })
        rStatus = spaced(label(12f, gray), 0.14f)
        rStatus.gravity = Gravity.CENTER
        c.addView(rStatus, lp(MATCH, WRAP).also { it.topMargin = u(6) })
        val prev = ctl(R.drawable.ic_prev, 44, 11, false)
        prev.setOnClickListener { playStation(prefs.radioIdx - 1) }
        rPlay = ctl(R.drawable.ic_play, 62, 16, true)
        rPlay.setOnClickListener { radioToggle() }
        val next = ctl(R.drawable.ic_next, 44, 11, false)
        next.setOnClickListener { playStation(prefs.radioIdx + 1) }
        c.addView(controlsRow(prev, rPlay, next), lp(MATCH, WRAP).also { it.topMargin = u(22) })
        val fm = linkText("FM  •  DEVICE RADIO") {
            val p = prefs.radioPkg
            if (p.isNotEmpty()) {
                val i = packageManager.getLaunchIntentForPackage(p)
                if (i != null) startActivity(i) else pickApp(202)
            } else {
                pickApp(202)
            }
        }
        fm.setOnLongClickListener { pickApp(202); true }
        c.addView(fm, lp(WRAP, WRAP).also { it.topMargin = u(10) })
        addClose(cardRadio)
    }

    private fun openCard(c: FlipCard) {
        for (o in cards) {
            if (o !== c && o.flipped) o.flipTo(false)
        }
        c.flipTo(true)
    }

    // =====================================================================
    // رادیو
    private fun playStation(i: Int) {
        val list = Stations.load(prefs)
        if (list.isEmpty()) return
        val idx = ((i % list.size) + list.size) % list.size
        prefs.radioIdx = idx
        music.svc?.radioPlay(list[idx].first, list[idx].second)
    }

    private fun radioToggle() {
        val s = music.svc ?: return
        if (s.radioState != 0) s.radioStop() else playStation(prefs.radioIdx)
    }

    // =====================================================================
    // بلوتوث
    private fun btCtl(code: Int) {
        val tc = music.ext.active?.transportControls
        if (tc != null) {
            when (code) {
                KeyEvent.KEYCODE_MEDIA_NEXT -> tc.skipToNext()
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> tc.skipToPrevious()
                else -> if (music.ext.isPlaying) tc.pause() else tc.play()
            }
            return
        }
        try {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (_: Exception) {
        }
    }

    // =====================================================================
    // مسیریابی: سرعت، هشدار فلش روی خط قرمز
    private fun onNav() {
        if (NavCore.arrivedFlag) {
            NavCore.arrivedFlag = false
            toast("به مقصد رسیدید")
        }
        val stale = NavCore.lastLoc != null && SystemClock.elapsedRealtime() - NavCore.lastLocAt > 5000
        val kmh = if (stale) 0f else NavCore.curKmh
        val v = if (prefs.speedUnit == 1) kmh * 0.621371f else kmh
        gpsSpeed.text = "" + v.roundToInt()
        gpsUnit.setFa(if (prefs.speedUnit == 1) "MPH" else "KM/H", true)

        var dir = 0
        var dist = 0.0
        val pr = NavCore.progress
        val nx = pr?.next
        if (NavCore.route != null && pr != null && nx != null) {
            val mod = nx.modifier
            val d = if (mod.contains("left")) -1 else if (mod.contains("right")) 1 else if (mod == "uturn") -1 else 0
            val th = if (prefs.alertDist > 0) prefs.alertDist.toDouble() else max(250.0, min(1000.0, kmh / 3.6 * 18.0))
            if (d != 0 && nx.type != "arrive" && pr.distToNext < th) {
                dir = d
                dist = pr.distToNext
            }
            gpsArrow.visibility = View.VISIBLE
            gpsArrow.rotation = Nav.arrowAngle(nx.type, nx.modifier)
            gpsHint.setFa(Nav.fmtDist(pr.distToNext) + "  •  " + Nav.fmtDur(pr.remainingTime))
        } else {
            gpsArrow.visibility = View.GONE
            gpsHint.setFa(if (NavCore.lastLoc == null) "WAITING FOR GPS" else "TAP FOR MAP")
        }
        neon.alertDir = if (dir == 0) 1 else dir
        neon.alertText = Nav.fmtDist(dist)
        updateNeonMode(dir != 0)
    }

    private fun audioActive(): Boolean {
        val s = music.svc
        return (s != null && (s.isPlaying || s.radioPlaying)) || music.ext.isPlaying
    }

    private fun updateNeonMode(alert: Boolean) {
        neon.mode = if (alert) 2 else if (audioActive()) 1 else 0
    }

    private fun manageAudioLevel() {
        val s = music.svc
        val session = if (s != null && s.radioPlaying) s.radioSessionId
        else if (s != null && s.isPlaying) s.audioSessionId
        else if (music.ext.isPlaying) 0
        else -1
        if (session != attachedSession) {
            attachedSession = session
            if (session >= 0 && granted(Manifest.permission.RECORD_AUDIO)) level.attach(session) else level.release()
        }
        neon.sim = audioActive() && !level.live
    }

    // =====================================================================
    // به‌روزرسانی دوره‌ای
    private fun tick() {
        val fmt = SimpleDateFormat(if (prefs.clock24) "HH:mm" else "hh:mm a", Locale.ENGLISH)
        clockTv.setFa(fmt.format(Date()), true)
        dateTv.setFa(dateText(prefs.dateMode))
        dateTv.visibility = if (prefs.dateMode == 0) View.GONE else View.VISIBLE

        val bt = radios.btOn()
        val wf = radios.wifiOn()
        btStatus.alpha = if (bt) 1f else 0.3f
        wifiStatus.alpha = if (wf) 1f else 0.3f
        var gpsOn = false
        try {
            val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
            gpsOn = lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)
        } catch (_: Exception) {
        }
        gpsStatus.alpha = if (gpsOn) 1f else 0.3f

        btSwitch.checked = bt
        btSub.setFa(if (bt) "ON" else "OFF", true)
        btSub.setTextColor(if (bt) red else gray)
        btState.setFa(if (bt) "BLUETOOTH  ON" else "BLUETOOTH  OFF", true)

        tickMusic()
        onNav()
        manageAudioLevel()
    }

    private fun tickMusic() {
        music.decide()
        val s = music.svc

        // موزیک داخلی
        val t = s?.currentTrack
        val localPlaying = s != null && s.isPlaying
        musicSub.setFa(if (localPlaying && t != null) t.title else if (t != null) "READY" else "NO MUSIC")
        mTitle.setFa(t?.title ?: "NO MUSIC", true)
        mArtist.setFa(t?.artist ?: "")
        mPlay.setImageResource(if (localPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        if (s != null) {
            val d = s.duration
            if (!mProg.dragging) mProg.fraction = if (d > 0) s.position.toFloat() / d else 0f
        }
        val key = if (t == null) "none" else "L" + t.id
        if (key != artKey) {
            artKey = key
            if (t == null) {
                mArt.bitmap = null
            } else {
                Thread {
                    val b = ArtLoader.load(this, t)
                    runOnUiThread { if (artKey == key) mArt.bitmap = b }
                }.start()
            }
        }

        // بلوتوث (صدای دریافتی از گوشی)
        val e = music.ext
        btTitle.setFa(e.title ?: "Bluetooth Audio", true)
        btPlay.setImageResource(if (e.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)

        // رادیو
        val rs = s?.radioState ?: 0
        val list = Stations.load(prefs)
        val idx = if (list.isEmpty()) 0 else ((prefs.radioIdx % list.size) + list.size) % list.size
        val name = if (s != null && rs != 0 && s.radioName.isNotEmpty()) s.radioName else if (list.isNotEmpty()) list[idx].first else "—"
        rName.setFa(name, true)
        rStatus.setFa(if (rs == 2) "● LIVE" else if (rs == 1) "CONNECTING..." else "STOPPED")
        rStatus.setTextColor(if (rs == 2) red else gray)
        rPlay.setImageResource(if (rs != 0) R.drawable.ic_pause else R.drawable.ic_play)
        radioSub.setFa(if (rs == 2) name else if (rs == 1) "CONNECTING..." else "OFFLINE")
        radioSub.setTextColor(if (rs == 2) red else gray)
        musicSub.setTextColor(if (localPlaying) red else gray)
        updateNeonMode(neon.mode == 2)
    }

    // =====================================================================
    private fun granted(p: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        if (Build.VERSION.SDK_INT < 23 || askedPerms) return
        askedPerms = true
        val need = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION, music.audioPerm(), Manifest.permission.RECORD_AUDIO
        ).filter { !granted(it) }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        music.loadIfPermitted()
        NavCore.permissionChanged(this)
        attachedSession = -2
    }

    private fun pickApp(req: Int) {
        startActivityForResult(Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK, true), req)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val pkg = data.getStringExtra(AppsActivity.EXTRA_PKG) ?: return
        if (req == 201) prefs.phonePkg = pkg
        else if (req == 202) prefs.radioPkg = pkg
    }
}
