package com.carlauncher.player

/** ایستگاه‌های رادیوی اینترنتی (نام و آدرس). کاربر می‌تواند در تنظیمات اضافه کند. */
object Stations {
    fun defaults(): List<Pair<String, String>> = listOf(
        Pair("SomaFM Groove Salad", "https://ice.somafm.com/groovesalad"),
        Pair("SomaFM Lush", "https://ice.somafm.com/lush"),
        Pair("SomaFM Fluid", "https://ice.somafm.com/fluid"),
        Pair("SomaFM Indie Pop Rocks", "https://ice.somafm.com/indiepop"),
        Pair("SomaFM Left Coast 70s", "https://ice.somafm.com/seventies"),
        Pair("SomaFM Seven Inch Soul", "https://ice.somafm.com/7soul")
    )

    fun load(p: Prefs): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (line in p.radioStations.split("\n")) {
            val i = line.indexOf("|")
            if (i > 0 && i < line.length - 1) out.add(Pair(line.substring(0, i).trim(), line.substring(i + 1).trim()))
        }
        return if (out.isEmpty()) defaults() else out
    }

    fun save(p: Prefs, list: List<Pair<String, String>>) {
        p.radioStations = list.joinToString("\n") {
            it.first.replace("|", " ").replace("\n", " ") + "|" + it.second.replace("\n", "")
        }
    }
}
