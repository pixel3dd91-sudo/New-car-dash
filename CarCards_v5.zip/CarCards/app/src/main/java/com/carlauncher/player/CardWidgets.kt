package com.carlauncher.player

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

fun Context.cardBg(): GradientDrawable {
    val g = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(0xFF2A2A2D.toInt(), 0xFF101012.toInt())
    )
    g.setCornerRadius(u(20).toFloat())
    g.setStroke(u(1), 0xFF3C3C42.toInt())
    return g
}

// ======================================================================
/** کارت با دو رو که حول محور عمودی می‌چرخد */
class FlipCard(ctx: Context) : FrameLayout(ctx) {
    val front = FrameLayout(ctx)
    val back = FrameLayout(ctx)
    var flipped = false
        private set
    var onFlip: ((Boolean) -> Unit)? = null
    private var busy = false

    init {
        front.background = ctx.cardBg()
        back.background = ctx.cardBg()
        val cd = ctx.resources.displayMetrics.density * 12000f
        front.cameraDistance = cd
        back.cameraDistance = cd
        addView(front, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(back, FrameLayout.LayoutParams(MATCH, MATCH))
        back.visibility = View.GONE
    }

    fun flipTo(toBack: Boolean) {
        if (flipped == toBack || busy) return
        busy = true
        flipped = toBack
        val outV = if (toBack) front else back
        val inV = if (toBack) back else front
        outV.animate().rotationY(if (toBack) 90f else -90f).setDuration(230)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                outV.visibility = View.GONE
                outV.rotationY = 0f
                inV.rotationY = if (toBack) -90f else 90f
                inV.visibility = View.VISIBLE
                inV.animate().rotationY(0f).setDuration(260)
                    .setInterpolator(DecelerateInterpolator())
                    .withEndAction { busy = false }
                    .start()
            }.start()
        onFlip?.invoke(toBack)
    }
}

// ======================================================================
/** کلید روشن/خاموش نئونی (وضعیت از بیرون تعیین می‌شود) */
class NeonSwitch @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var checked = false
        set(v) {
            if (field != v) {
                field = v
                animateKnob()
            }
        }
    var onTap: (() -> Unit)? = null
    private var pos = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun animateKnob() {
        val a = ValueAnimator.ofFloat(pos, if (checked) 1f else 0f)
        a.duration = 220
        a.addUpdateListener {
            pos = it.animatedValue as Float
            invalidate()
        }
        a.start()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        p.style = Paint.Style.FILL
        p.color = blendColors(0xFF2A2A2E.toInt(), 0xFF8A0F0F.toInt(), pos)
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = context.u(2).toFloat()
        p.color = blendColors(0xFF55555C.toInt(), 0xFFFF2A2A.toInt(), pos)
        c.drawRoundRect(1f, 1f, w - 1f, h - 1f, r, r, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        val kr = r * 0.74f
        c.drawCircle(r + (w - 2 * r) * pos, h / 2f, kr, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

// ======================================================================
/**
 * خط قرمز نئونی دور کارت‌ها.
 * mode 0: ساکن با تپش آرام | 1: نوار قلب هم‌زمان با صدا | 2: فلش چپ/راست (هشدار مسیریابی)
 */
class NeonLineView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var mode = 0
    var alertDir = 1
    var alertText = ""
    var sim = false
    var insetX = 0f
    var insetTop = 0f
    var insetBottom = 0f
    var cardInset = 0f
    var cardGap = 0f
    var cardCount = 4

    private val red = Color.parseColor("#FF2020")
    private val core = blendColors(Color.parseColor("#FF2020"), Color.WHITE, 0.5f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loop = Path()
    private val wave = Path()
    private val tmp = Path()
    private val buf = FloatArray(260)
    private var beatT = -1f
    private var beatAmp = 0f
    private var acc = 0f
    private var lastMs = 0L
    private var chev = 0f
    private var nextSim = 0L

    init {
        txt.textAlign = Paint.Align.CENTER
    }

    fun beat(a: Float) {
        if (beatT < 0f || beatT > 0.30f) {
            beatT = 0f
            beatAmp = a.coerceIn(0.25f, 1f)
        }
    }

    private fun g(t: Float, c: Float, w: Float): Float {
        val x = (t - c) / w
        return exp(-x * x)
    }

    private fun shape(t: Float): Float =
        0.10f * g(t, 0.06f, 0.030f) - 0.12f * g(t, 0.125f, 0.014f) + 1.0f * g(t, 0.155f, 0.016f) -
            0.24f * g(t, 0.19f, 0.014f) + 0.24f * g(t, 0.34f, 0.05f)

    private fun stepWave(dt: Float) {
        acc += dt * 110f
        var guard = 0
        while (acc >= 1f && guard < 20) {
            acc -= 1f
            guard++
            System.arraycopy(buf, 1, buf, 0, buf.size - 1)
            var v = (Math.random().toFloat() - 0.5f) * 0.03f
            if (beatT >= 0f) {
                v += shape(beatT) * beatAmp
                beatT += 1f / 110f
                if (beatT > 0.6f) beatT = -1f
            }
            buf[buf.size - 1] = v
        }
    }

    private fun glow(c: Canvas, path: Path, a: Float) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = red
        val ws = floatArrayOf(7f, 4f, 2f)
        val al = intArrayOf(26, 66, 255)
        for (i in 0 until 3) {
            p.strokeWidth = context.u(ws[i]).toFloat()
            p.alpha = (al[i] * a).toInt().coerceIn(0, 255)
            c.drawPath(path, p)
        }
        p.color = core
        p.alpha = (255 * a).toInt().coerceIn(0, 255)
        p.strokeWidth = context.u(1).toFloat()
        c.drawPath(path, p)
        p.alpha = 255
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastMs == 0L) 0.016f else ((now - lastMs).coerceIn(1L, 100L)) / 1000f
        lastMs = now

        val w = width.toFloat()
        val h = height.toFloat()
        val l = insetX
        val r = w - insetX
        val t = insetTop
        val b = h - insetBottom
        val rad = min(context.u(28).toFloat(), (b - t) / 3f)
        val pulse = 0.80f + 0.20f * sin(now / 900.0).toFloat()

        // حلقه‌ی دور کارت‌ها (بدون لبه‌ی پایین)
        loop.reset()
        loop.moveTo(r - rad, b)
        loop.arcTo(RectF(r - 2 * rad, b - 2 * rad, r, b), 90f, -90f)
        loop.lineTo(r, t + rad)
        loop.arcTo(RectF(r - 2 * rad, t, r, t + 2 * rad), 0f, -90f)
        loop.lineTo(l + rad, t)
        loop.arcTo(RectF(l, t, l + 2 * rad, t + 2 * rad), 270f, -90f)
        loop.lineTo(l, b - rad)
        loop.arcTo(RectF(l, b - 2 * rad, l + 2 * rad, b), 180f, -90f)
        glow(c, loop, pulse)

        // رابط‌های کوچک بین کارت‌ها و دو سر خط
        val midY = (t + b) / 2f
        val innerL = l + cardInset
        val innerR = r - cardInset
        val cw = (innerR - innerL - (cardCount - 1) * cardGap) / cardCount
        for (k in 1 until cardCount) {
            val gx = innerL + k * cw + (k - 0.5f) * cardGap
            tmp.reset()
            tmp.moveTo(gx - cardGap * 0.36f, midY)
            tmp.lineTo(gx + cardGap * 0.36f, midY)
            glow(c, tmp, pulse)
            p.style = Paint.Style.FILL
            p.color = red
            c.drawCircle(gx, midY, context.u(3).toFloat(), p)
        }
        tmp.reset()
        tmp.moveTo(0f, midY)
        tmp.lineTo(l, midY)
        glow(c, tmp, pulse)
        tmp.reset()
        tmp.moveTo(r, midY)
        tmp.lineTo(w - context.u(8), midY)
        tmp.moveTo(w - context.u(16), midY - context.u(8))
        tmp.lineTo(w - context.u(8), midY)
        tmp.lineTo(w - context.u(16), midY + context.u(8))
        glow(c, tmp, pulse)

        // لبه‌ی پایین: ساکن، نوار قلب یا فلش هشدار
        val x0 = l + rad
        val x1 = r - rad
        when (mode) {
            1 -> {
                if (sim && now >= nextSim) {
                    beat(0.5f + Math.random().toFloat() * 0.5f)
                    nextSim = now + 540L + (Math.random() * 260.0).toLong()
                }
                stepWave(dt)
                val amp = context.u(24).toFloat()
                wave.reset()
                for (i in buf.indices) {
                    val x = x0 + (x1 - x0) * i / (buf.size - 1)
                    val y = b - buf[i] * amp
                    if (i == 0) wave.moveTo(x, y) else wave.lineTo(x, y)
                }
                glow(c, wave, 1f)
            }
            2 -> {
                tmp.reset()
                tmp.moveTo(x0, b)
                tmp.lineTo(x1, b)
                p.style = Paint.Style.STROKE
                p.color = red
                p.alpha = 70
                p.strokeWidth = context.u(2).toFloat()
                c.drawPath(tmp, p)
                p.alpha = 255

                val span = x1 - x0
                val sp = context.u(54).toFloat()
                chev += dt * context.u(170).toFloat()
                val s = context.u(12).toFloat()
                val n = (span / sp).toInt() + 1
                val d = alertDir
                for (k in 0 until n) {
                    var off = (k * sp + chev) % span
                    if (off < 0f) off += span
                    val x = if (d > 0) x0 + off else x1 - off
                    val frac = off / span
                    val a = sin(Math.PI * frac).toFloat().coerceIn(0.15f, 1f)
                    tmp.reset()
                    tmp.moveTo(x - d * s, b - s)
                    tmp.lineTo(x, b)
                    tmp.lineTo(x - d * s, b + s)
                    glow(c, tmp, a)
                }
                txt.typeface = Fonts.forText(context, "0", true)
                txt.color = Color.WHITE
                txt.textSize = context.u(22).toFloat()
                c.drawText(alertText, (x0 + x1) / 2f, b - context.u(20).toFloat(), txt)
            }
            else -> {
                tmp.reset()
                tmp.moveTo(x0, b)
                tmp.lineTo(x1, b)
                glow(c, tmp, pulse)
            }
        }

        if (mode == 0) postInvalidateDelayed(70) else postInvalidateOnAnimation()
    }
}
