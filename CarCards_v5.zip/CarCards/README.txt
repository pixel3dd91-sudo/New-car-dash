Car Cards (v5) - لانچر کارتی مشکی با خط قرمز نئونی
ساخت APK: فایل zip را در یک repository آپلود کنید و فایل .github/workflows/build.yml (همان فایل ساخت قبلی) را بسازید.
